import pygame
from pygame.locals import *

from models.GUI.GUI_button import *
from models.GUI.GUI_label import *
from models.GUI.GUI_form import *
from models.GUI.GUI_button_image import *
from auxiliar.constantes import *



class formSeleccionNivel(Form):
    
    def __init__(self, screen: pygame.Surface, x: int, y: int, w:int, h: int, color_background, color_border = "Black", border_size: int = -1, active = True):
        super().__init__(screen, x,y,w,h,color_background, color_border, border_size, active)
        
        
        
        self.btn_play_stage1 = Button(self._slave, x, y, 210, 25, 30, 40,
                            "red", "blue",self.btn_play_click1, "",
                            path_font, path_font,15, "white")
        
        self.btn_play_stage2 = Button(self._slave, x, y, 210, 85, 30, 40,
                            "red", "blue",self.btn_play_click2, "",
                            path_font, path_font,15, "white")
        
        self.btn_play_stage3 = Button(self._slave, x, y, 210, 145, 30, 40,
                            "red", "blue",self.btn_play_click3, "",
                            path_font, path_font,15, "white")
        
        self.label_Stage_1 = Label(self._slave,200,20, 80, 50, "Stage 1",
                                path_font, 15,"white", "assets/graphics/interfaz/Table.png")

        self.label_Stage_2 = Label(self._slave,200,80, 80, 50, "Stage 2",
                                path_font, 15,"white", "assets/graphics/interfaz/Table.png")
        
        self.label_Stage_3 = Label(self._slave,200,140, 80, 50, "Stage 3- Final",
                                path_font, 15,"white", "assets/graphics/interfaz/Table.png")
        
        
        
        self.lista_widgets.append(self.btn_play_stage1)
        self.lista_widgets.append(self.btn_play_stage2)
        self.lista_widgets.append(self.btn_play_stage3)
        self.lista_widgets.append(self.label_Stage_1)
        self.lista_widgets.append(self.label_Stage_2)
        self.lista_widgets.append(self.label_Stage_3)        
        
        
    def render(self):
        self._slave.fill(self._color_background)
        
    def update(self, lista_eventos):
        if self.verificar_dialog_result():
            if self.active:
                self.draw()
                self.render()
                for widget in self.lista_widgets:
                    widget.update(lista_eventos)#POLIMORFISMO
        else:
            self.hijo.update(lista_eventos)
            
            
            
    def btn_play_click1(self, param):
        if self.flag_play:
            pygame.mixer.music.pause()
            self.btn_play._color_background = "blue"
            self.btn_play.set_text("Play")
        else:
            
            pygame.mixer.music.unpause()
            self.btn_play._color_background = "red"
            self.btn_play.set_text("Pause")
            
        
        self.flag_play = not self.flag_play
            
    def btn_play_click2(self, param):
        if self.flag_play:
            pygame.mixer.music.pause()
            self.btn_play._color_background = "blue"
            self.btn_play.set_text("Play")
        else:
            
            pygame.mixer.music.unpause()
            self.btn_play._color_background = "red"
            self.btn_play.set_text("Pause")
            
        self.flag_play = not self.flag_play
        
    def btn_play_click3(self, param):
        if self.flag_play:
            pygame.mixer.music.pause()
            self.btn_play._color_background = "blue"
            self.btn_play.set_text("Play")
        else:
            
            pygame.mixer.music.unpause()
            self.btn_play._color_background = "red"
            self.btn_play.set_text("Pause")
            
        self.flag_play = not self.flag_play